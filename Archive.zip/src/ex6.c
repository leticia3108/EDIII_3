/*
* O código a seguir é relativo a funcionalidade de compactação eficiente
* do arquivo, através de uma desfragmentação.
* 
* A compactação irá remover os arquivos que foram marcados como removidos,
* deixando os que foram marcados como não-removidos.
* 
* Uma observação é que essa funcionalidade não deve remover o caractere '$'.
* 
* Como entrada dessa funcionalidade, o usuário deve selecionar um arquivo
* binário, que pode conter ou não regisstros logicamente removidos.
* 
* Aqui será feita a etapa principal, solicitando funções criadas no
* módulo 'common.c'
*/


#include "header.h"

void ex6 (){
    return;
}