// #include "../include/common.hpp"
// #include "../include/ex12.hpp"

// void ex12(FILE* binario){
//     Grafo g(binario);
//     g.CriaGrafo();
//     g.CiclosSimples();
// }