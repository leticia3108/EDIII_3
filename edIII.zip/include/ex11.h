#ifndef EX11_H
#define EX11_H

void ex11(FILE* binario_entrada);

#endif