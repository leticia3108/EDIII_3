#ifndef EX11_H
#define EX11_H

void ex11(FILE* binario_entrada);
void scan_quote_string(char *str);

#endif