#ifndef EX12_HPP
#define EX12_HPP

void ex12(FILE* binario_entrada);

#endif