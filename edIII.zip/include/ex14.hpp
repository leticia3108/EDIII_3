#ifndef EX14_HPP
#define EX14_HPP

void ex14(Grafo &);

#endif