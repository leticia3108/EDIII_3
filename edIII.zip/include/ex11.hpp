#ifndef EX11_HPP
#define EX11_HPP

void ex11(const Grafo &, const char *);

#endif // EX11_HPP