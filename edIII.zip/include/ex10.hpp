// #ifndef EX10_HPP
// #define EX10_HPP

// void ex10(FILE* binario_entrada);

// #endif // EX10_HPP